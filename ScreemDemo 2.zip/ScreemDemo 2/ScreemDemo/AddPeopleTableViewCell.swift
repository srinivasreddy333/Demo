//
//  AddPeopleTableViewCell.swift
//  ScreemDemo
//
//  Created by Vivek Dharmani on 08/05/19.
//  Copyright © 2019 Vivek Dharmani. All rights reserved.
//

import UIKit

class AddPeopleTableViewCell: UITableViewCell {
    @IBOutlet weak var nameLbl: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
